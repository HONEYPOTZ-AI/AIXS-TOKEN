# AIXS Token Deployment

## Features
- ERC-20 Token with minting and ownership
- Vesting logic
- Governance framework

## Setup
1. Install Node.js and Hardhat
2. Run `npm install` to install dependencies
3. Use `npx hardhat run scripts/deploy.js` to deploy

## Integration
Designed for SAAS FLUIDITY and SAASBANK platforms.
